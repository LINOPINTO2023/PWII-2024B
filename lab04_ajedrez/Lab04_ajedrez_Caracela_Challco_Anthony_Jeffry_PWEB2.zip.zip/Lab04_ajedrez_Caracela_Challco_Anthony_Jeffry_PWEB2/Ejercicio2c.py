from interpreter import draw
from chessPictures import *
draw(queen.join(queen).join(queen).join(queen))
