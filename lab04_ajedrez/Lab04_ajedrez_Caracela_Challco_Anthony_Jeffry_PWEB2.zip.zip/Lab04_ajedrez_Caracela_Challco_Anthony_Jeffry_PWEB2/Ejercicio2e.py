from interpreter import draw
from chessPictures import *
draw(square.negative().join(square).horizontalRepeat(4))
