from interpreter import draw
from chessPictures import *
draw(square.join(square.negative()).horizontalRepeat(4))
